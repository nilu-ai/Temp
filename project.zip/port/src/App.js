// src/App.js
import React from 'react';

const App = () => {
  const headerStyle = {
    backgroundColor: '#282c34',
    padding: '20px',
    color: 'white',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  };

  const headerNavStyle = {
    listStyle: 'none',
    display: 'flex',
    margin: 0,
    padding: 0,
  };

  const headerNavItemStyle = {
    marginRight: '15px',
  };

  const headerNavLinkStyle = {
    color: 'white',
    textDecoration: 'none',
  };

  const sectionStyle = {
    padding: '50px',
    textAlign: 'center',
  };

  const aboutStyle = {
    ...sectionStyle,
  };

  const skillsStyle = {
    ...sectionStyle,
    backgroundColor: '#f4f4f4',
  };

  const projectsStyle = {
    ...sectionStyle,
  };

  const contactStyle = {
    ...sectionStyle,
    backgroundColor: '#282c34',
    color: 'white',
  };

  return (
    <div className="App">
      <header style={headerStyle}>
        <h1>Nilesh Raut</h1>
        <nav>
          <ul style={headerNavStyle}>
            <li style={headerNavItemStyle}><a href="#about" style={headerNavLinkStyle}>About</a></li>
            <li style={headerNavItemStyle}><a href="#skills" style={headerNavLinkStyle}>Skills</a></li>
            <li style={headerNavItemStyle}><a href="#projects" style={headerNavLinkStyle}>Projects</a></li>
            <li style={headerNavItemStyle}><a href="#contact" style={headerNavLinkStyle}>Contact</a></li>
          </ul>
        </nav>
      </header>

      <section id="about" style={aboutStyle}>
        <h2>About Me</h2>
        <p>I am a passionate developer with expertise in MERN stack, backend development, SQL, NoSQL, and Machine Learning.</p>
      </section>

      <section id="skills" style={skillsStyle}>
        <h2>Skills</h2>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li>MERN Stack</li>
          <li>Backend Development</li>
          <li>SQL</li>
          <li>NoSQL</li>
          <li>Machine Learning</li>
        </ul>
      </section>

      <section id="projects" style={projectsStyle}>
        <h2>Projects</h2>
        <div style={{ margin: '20px 0' }}>
          <h3>Product Selling Website</h3>
          <p>A full-fledged e-commerce platform.</p>
        </div>
        <div style={{ margin: '20px 0' }}>
          <h3>ProLearning Platform</h3>
          <p>A student recommendation and improvement platform.</p>
        </div>
      </section>

      <section id="contact" style={contactStyle}>
        <h2>Contact</h2>
        <p>Email: your-email@example.com</p>
      </section>
    </div>
  );
};

export default App;